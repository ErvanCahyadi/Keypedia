@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-30 text-center">
            <h1>Welcome to Keypedia</h1>
            <h5>Best keyboard and Keycaps Shop</h5>

            <div class="item d-flex pt-3 justify-content-evenly flex-wrap">
            @foreach ($categories as $category)
                <div class="card mr-4 mb-4" style="width: 450px;">
                    <img class="card-img-top" src="{{asset('/storage/'.$category->image)}}" alt="Card image cap" style="height: 225px">
                    <div class="card-body">
                      <h5 class="card-title">{{$category->name}}</h5>
                      @if ( Auth::user()->name == 'admin')
                        <a href="/admin/category-view/{{$category->id}}" class="btn btn-primary">Details</a>
                      @else                          
                        <a href="product/{{$category->id}}" class="btn btn-primary">Details</a>
                      @endif

                    </div>
                  </div>
                @endforeach 
            </div>
          </div>
            </div>

            
           
    </div>
</div>
@endsection
