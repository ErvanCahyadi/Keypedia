@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-30 text-center">
            <strong>Welcome to Keypedia</strong>
            <p>Best keyboard and Keycaps Shop</p>

            <div class="item d-flex pt-3 justify-content-evenly flex-wrap">
            @foreach ($categories as $category)
                <div class="card mr-5" style="width: 18rem;">
                    <img class="card-img-top" src="{{asset('/storage/'.$category->image)}}" alt="Card image cap" style="height: 225px">
                    <div class="card-body">
                      <h5 class="card-title">{{$category->name}}</h5>
                      <div class="buttons d-flex mx-3 justify-content-center">
                          <a href="/admin/category/{{$category->id}}" class="btn btn-primary">Update</a>
                          <form action="/admin/category/delete/{{$category->id}}" method="post">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-primary ml-2">Delete</button>
                          </form>
                    </div>
                    </div>
                  </div>
                @endforeach 
            </div>
          </div>
        </div>
    </div>
</div>
@endsection
