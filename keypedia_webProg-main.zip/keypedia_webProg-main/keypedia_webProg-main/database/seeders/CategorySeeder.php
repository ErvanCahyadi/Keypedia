<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('categories')->insert([
            'name' => '87 Key Keyboard',
            'image' => '87Keyboard.jpg'
        ]);

        DB::table('categories')->insert([
            'name' => '61 Key Keyboard',
            'image' => '61Keyboard.jpg'
        ]);

        DB::table('categories')->insert([
            'name' => 'Membrane Keyboard',
            'image' => 'Membrane Keyboard.jpg'
        ]);
        //
    }
}
