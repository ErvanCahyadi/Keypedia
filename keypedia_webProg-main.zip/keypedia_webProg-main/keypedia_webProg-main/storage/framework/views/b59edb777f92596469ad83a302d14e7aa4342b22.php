<?php echo e($slot); ?>

<?php /**PATH E:\COLLEGE\Semester 5\Web Programming\Project\keypedia_webProg-main\keypedia_webProg-main\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>