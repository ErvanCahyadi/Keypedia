<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8 text-center">
            <h2>Your Transaction at <?php echo e($transactions->created_at); ?></h2>
            <div class="item d-flex pt-3 justify-content-evenly flex-wrap">
                <div class="card mr-5" style="width: 60rem;">
                    <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                    <div class="card-body">
                      <img src="<?php echo e($detail->product->image); ?>" alt="">
                      <h5 class="card-title"><?php echo e($detail->product->name); ?></h5>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
            </div>
           
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\keypedia_webProg-main\keypedia_webProg-main\resources\views/transaction-detail.blade.php ENDPATH**/ ?>