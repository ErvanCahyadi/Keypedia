

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8 text-center">
            <strong>Welcome to Keypedia</strong>
            <p>Best keyboard and Keycaps Shop</p>

            <form class="mb-4" action="/admin/category/update/<?php echo e($categories->id); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                
      
                <div class="form-group row">
                  <label  class="col-md-4 col-form-label text-md-right">Category Name</label>
      
                  <div class="col-md-6">
                      <input  class="form-control" name="category_name" value="<?php echo e($categories->name); ?>">
                  </div>
              </div>
      
              <div class="form-group row">
                  <label  class="col-md-4 col-form-label text-md-right">Upload File</label>
      
                  <div class="col-md-6">
                      <input  class="form-control" name="image" type="file" >
                  </div>
              </div>
              <button type="submit" class="btn btn-danger">Submit</button>

            </form>

            
          
        
           
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\keypedia_webProg-main\keypedia_webProg-main\resources\views/Admin/update-category.blade.php ENDPATH**/ ?>