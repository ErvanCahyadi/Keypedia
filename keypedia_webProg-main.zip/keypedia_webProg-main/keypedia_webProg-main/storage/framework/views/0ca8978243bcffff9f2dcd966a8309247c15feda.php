<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8 text-center">
            <strong>Welcome to Keypedia</strong>
            <p>Best keyboard and Keycaps Shop</p>

            <div class="card d-flex justify-content-center" style="width: 18rem;">
                <div class="card-body">
                    <p>Keyboard Name: <?php echo e($products->name); ?></p>
                    <p>Keyboard Price: <?php echo e($products->price); ?></p>
                    <p>Keyboard Description: <?php echo e($products->description); ?></p>
                    <p>Keyboard Image:</p> <img src="<?php echo e(asset('/storage/'.$products->image)); ?>" width="200px" height="100px">
                    <div class="buttons d-flex ml-4">
                        <form action="/cart/store" method="post">
                          <?php echo csrf_field(); ?>
                          <input type="hidden" name="item_id" value="<?php echo e($products->id); ?>">
                          <input type="hidden" name="image" value="<?php echo e($products->image); ?>">
                          Quantity: <input type="number"  name="quantity" value="<?php echo e($products->quantity); ?>">
                          <input type="submit" class="btn btn-primary" value="Add To Cart">
                        </form>
                      </div>
                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\COLLEGE\Semester 5\Web Programming\Project\keypedia_webProg-main\keypedia_webProg-main\resources\views/detail.blade.php ENDPATH**/ ?>