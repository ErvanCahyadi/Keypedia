<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8 text-center">
            <strong>Welcome to Keypedia</strong>
            <p>Best keyboard and Keycaps Shop</p>

            <div class="row list-product pt-3 justify-content-evenly flex-wrap">
                <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mr-5 mb-3" style="width: 10rem;">
                    <img class="card-img-top" src="<?php echo e(asset('/storage/'.$cart->image)); ?>" alt="Card image cap">
                    <div class="card-body">
                      <a href="/cart-detail/<?php echo e($cart->products->id); ?>"><h5 class="card-title "><?php echo e($cart->products->name); ?></h5></a>
                    </div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </div>
            <form action="/checkout" method="post">
              <?php if($carts->isEmpty()): ?>
                  <p class="bg-warning">Your Cart is empty</p>
              <?php else: ?>
              <form action="/checkout" method="post">
                <?php echo csrf_field(); ?>
                <button class="btn btn-primary" type="submit">Checkout</button>
              </form>
              <?php endif; ?>
          
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\keypedia_webProg-main\keypedia_webProg-main\resources\views//cart.blade.php ENDPATH**/ ?>