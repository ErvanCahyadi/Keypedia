<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8 text-center">
            <h2>Your Transaction at <?php echo e($transactions->created_at); ?></h2>
            <div class="row item d-flex pt-5 justify-content-evenly flex-wrap">
                <div class="card mr-10 mb-5" style="background-color:darkcyan;">
                    <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <div class="row row-cols-1 row-cols-md-2 g-4">
                      <div class="col">
                        <div class="card mx-3" style="width: 270px; height: 450px; ">
                          <img src="<?php echo e(asset('storage/'.$detail->product->image)); ?>" style="max-width: 270px; max-height: 300px;"class="card-img-top" alt="...">
                          <h5 class="card-title"><?php echo e($detail->product->name); ?></h5>
                          <div class="card-body">
                            <p>Keyboard Price: <?php echo e($detail->product->price); ?></p>
                            <p>Keyboard Description: <?php echo e($detail->product->description); ?></p>
                          </div>
                        </div>
                      </div>
                      <div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
            </div>
           
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\COLLEGE\Semester 5\Web Programming\Project\keypedia_webProg-main\keypedia_webProg-main\resources\views/transaction-detail.blade.php ENDPATH**/ ?>