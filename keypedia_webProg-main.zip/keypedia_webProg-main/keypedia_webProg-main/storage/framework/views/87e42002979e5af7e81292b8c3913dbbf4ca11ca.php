<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-30 text-center">
            <h1>Welcome to Keypedia</h1>
            <h5>Best keyboard and Keycaps Shop</h5>

            <div class="item d-flex pt-3 justify-content-evenly flex-wrap">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mr-4 mb-4" style="width: 450px;">
                    <img class="card-img-top" src="<?php echo e(asset('/storage/'.$category->image)); ?>" alt="Card image cap" style="height: 225px">
                    <div class="card-body">
                      <h5 class="card-title"><?php echo e($category->name); ?></h5>
                      <?php if( Auth::user()->name == 'admin'): ?>
                        <a href="/admin/category-view/<?php echo e($category->id); ?>" class="btn btn-primary">Details</a>
                      <?php else: ?>                          
                        <a href="product/<?php echo e($category->id); ?>" class="btn btn-primary">Details</a>
                      <?php endif; ?>

                    </div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </div>
          </div>
            </div>

            
           
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\COLLEGE\Semester 5\Web Programming\Project\keypedia_webProg-main\keypedia_webProg-main\resources\views/home.blade.php ENDPATH**/ ?>