<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8 text-center">
            <strong><?php echo e($categories->name); ?></strong>
            <div class="md-form mt-3">
                <input class="form-control" name="search" type="text" placeholder="Search" aria-label="Search">
              </div>

            <div class="item d-flex pt-3">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mr-5" style="width: 18rem;">
                    <img class="card-img-top" src="<?php echo e(asset('/storage/'.$product->image)); ?>" alt="Card image cap">
                    <div class="card-body">
                      <h5 class="card-title"><?php echo e($product->name); ?></h5>
                      <div class="buttons d-flex">
                        <a href="/update/<?php echo e($product->id); ?>" class="btn btn-primary">Update</a>
                        <form action="/delete/<?php echo e($product->id); ?>" method="post">
                          <?php echo csrf_field(); ?>
                          <?php echo method_field('DELETE'); ?>
                          <button type="submit" class="btn btn-primary ml-2">Delete</button>
                        </form>
                      </div>
                    </div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </div>
           
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\keypedia_webProg-main\keypedia_webProg-main\resources\views/Admin/product-admin.blade.php ENDPATH**/ ?>