<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8 text-center">
            <strong>Welcome to Keypedia</strong>
            <p>Best keyboard and Keycaps Shop</p>

            <form class="mb-4" action="/update-product/<?php echo e($product->id); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <div class="form-group row">
                    <label  class="col-md-4 col-form-label text-md-right">Category</label>
      
                    <div class="col-md-6">
                        <select name="category" class="form-control"  >

                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
      
                <div class="form-group row">
                  <label  class="col-md-4 col-form-label text-md-right">Keyboard Name</label>
      
                  <div class="col-md-6">
                      <input  class="form-control" name="product_name" value="<?php echo e($product->name); ?>">
                  </div>
              </div>
      
              <div class="form-group row">
                  <label  class="col-md-4 col-form-label text-md-right">Keyboard Price</label>
      
                  <div class="col-md-6">
                      <input  class="form-control" name="price" value="<?php echo e($product->price); ?>" >
                  </div>
              </div>
      
              <div class="form-group row">
                  <label  class="col-md-4 col-form-label text-md-right">Description</label>
      
                  <div class="col-md-6">
                      <input  class="form-control" name="description" value="<?php echo e($product->description); ?>">
                  </div>
              </div>
      
              <div class="form-group row">
                  <label  class="col-md-4 col-form-label text-md-right">Upload File</label>
      
                  <div class="col-md-6">
                      <input  class="form-control" name="image" type="file" >
                  </div>
              </div>
              <button type="submit" class="btn btn-danger">Submit</button>

            </form>

            
          
        
           
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\keypedia_webProg-main\keypedia_webProg-main\resources\views/update.blade.php ENDPATH**/ ?>