

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-30 text-center">
            <strong>Welcome to Keypedia</strong>
            <p>Best keyboard and Keycaps Shop</p>

            <div class="item d-flex pt-3 justify-content-evenly flex-wrap">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mr-5" style="width: 18rem;">
                    <img class="card-img-top" src="<?php echo e(asset('/storage/'.$category->image)); ?>" alt="Card image cap" style="height: 225px">
                    <div class="card-body">
                      <h5 class="card-title"><?php echo e($category->name); ?></h5>
                      <div class="buttons d-flex mx-3 justify-content-center">
                          <a href="/admin/category/<?php echo e($category->id); ?>" class="btn btn-primary">Update</a>
                          <form action="/admin/category/delete/<?php echo e($category->id); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-primary ml-2">Delete</button>
                          </form>
                    </div>
                    </div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </div>
          </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\keypedia_webProg-main\keypedia_webProg-main\resources\views/Admin/category-admin.blade.php ENDPATH**/ ?>