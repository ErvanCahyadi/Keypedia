<?php

use App\Http\Controllers\ShopController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\CartDetailController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\DetailController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\TransactionController;
use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [LoginController::class, 'index']);

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index_category'])->name('home');

Route::get('/product/{id}', [ShopController::class, 'category']);




//Cart

Route::get('/cart', [CartController::class, 'index']);

Route::post('/cart/store', [CartController::class, 'store']);

//Detail

Route::get('/detail/{id}', [DetailController::class, 'index']);

//Cart Detail

Route::get('/cart-detail/{id}', [CartDetailController::class, 'index']);

//Checkout

Route::post('/checkout', [CheckoutController::class, 'store']);

//Transaction History

Route::get('/transaction', [TransactionController::class, 'index']);

//Transaction Detail
Route::get('/transaction/detail/{id}', [TransactionController::class, 'detail']);

//Change Password
Route::get('/change-password', [App\Http\Controllers\Auth\AuthController::class, 'changePasswordView'])->name('change-password');
Route::put('password/update', [App\Http\Controllers\Auth\AuthController::class, 'update'])->name('change-password');

Route::middleware('admin')->group(function(){
    //home admin view
    Route::get('/admin/category', [AdminController::class,'indexHomeAdmin'])->name('category.index');
    Route::get('/admin/category/{id}', [AdminController::class, 'getCategoryById']);
    Route::get('/admin/category-view/{id}', [AdminController::class, 'productAdmin']);
    Route::patch('/admin/category/update/{category}', [AdminController::class, 'updateCategory']);
    Route::delete('/admin/category/delete/{id}', [AdminController::class, 'deleteCategory']);

    //product crud
    //product update
    Route::get('/update/{id}', [AdminController::class, 'editProduct']);
    Route::patch('/update-product/{id}', [AdminController::class, 'updateProduct']);
    // Route::get('/admin/product', [AdminController::class, 'index_product'])->name('product.index');
    Route::get('/admin/product', [AdminController::class, 'index_addProduct'])->name('product.get');
    // Route::get('/admin/product/{product}', [AdminController::class, 'getProductById'])->name('product.detail.get');
    Route::post('/admin/product/create', [AdminController::class, 'addProduct'])->name('product.store');
    Route::delete('/delete/{id}', [AdminController::class, 'DeleteProduct']);

});

